function wrat(s,nb,unit)

    fwrite(s, [char(sprintf('wrat ' + string(nb) + ' ' + unit)) char([13 10])]);

end