function aurevoir_pompe(s)

% --- 5. FERMETURE ---
    fclose(s);
    delete(s);
    clear s;
    disp('Au revoir la pompe !');

end