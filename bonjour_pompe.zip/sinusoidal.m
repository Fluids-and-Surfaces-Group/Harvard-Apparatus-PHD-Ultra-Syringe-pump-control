
port = "COM10";

s = bonjour_pompe(port);

debit_max = 60; % mL/min MAX - À ADAPTER!
unit = 'ul/m';
diameter = 25;

frequence = 0.05; % Hz
duree = 60; % secondes
dt = 0.05; % mise à jour chaque seconde

fprintf('Démarrage contrôle sinusoïdal...\n');

t_start = tic;

t_ecoule = 0;
debit_init = debit_max * sin(2*pi*frequence*t_ecoule);
signant = sign(debit_init);
irat(s,debit_init,unit);
irun(s);
while toc(t_start) < duree
    t_ecoule = toc(t_start);
    
    % Sinusoïde 0 → debit_max
    debit_volumique = debit_max * sin(2*pi*frequence*t_ecoule);

    signpost = sign(debit_volumique);
    
    if debit_volumique >=0 && signpost*signant == 1

        irat(s,debit_volumique,unit);

    elseif debit_volumique >=0 && signpost*signant == -1

        irat(s,debit_volumique,unit);
        irun(s);

    elseif debit_volumique < 0 && signpost*signant == 1

        wrat(s,-debit_volumique,unit);

    else

        wrat(s,-debit_volumique,unit);
        wrun(s)

    end

    signant = signpost;
    
    fprintf('T: %0.1fs, Débit: %0.2f mL/min\n', t_ecoule, debit_volumique);
    pause(dt);
end

stop(s);

aurevoir_pompe(s);
