function wrun(s)

    fwrite(s, [char(sprintf('wrun')) char([13 10])]);

end