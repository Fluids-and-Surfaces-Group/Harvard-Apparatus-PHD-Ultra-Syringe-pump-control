function irat(s,nb,unit)

    fwrite(s, [char(sprintf('irat ' + string(nb) + ' ' + unit)) char([13 10])]);

end