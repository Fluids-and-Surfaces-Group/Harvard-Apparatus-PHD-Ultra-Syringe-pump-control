%% === Contrôle Harvard PHD Ultra via port série ===
% Ce script :
%  1. établit la communication série
%  2. envoie des commandes ASCII à la pompe
%  3. fait un cycle simple : run 10 s puis stop

function [s] = bonjour_pompe(port)

    % --- PARAMÈTRES DU PORT USB / COM ---
    %port = "COM10";   % ⚠️ adapte selon ton PC (vérifie dans le gestionnaire de périphériques)
    baud = 9600;      % standard Harvard PHD Ultra
    timeout = 5;

    % --- INITIALISATION ---
    s = serialport(port, baud, "Timeout", timeout);

    % Petit délai pour stabiliser la liaison
    pause(1.0);

    disp('Bonjour la pompe !');


end
