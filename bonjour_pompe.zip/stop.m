function stop(s)

    fwrite(s, [char(sprintf('stop')) char([13 10])]);

end