function irun(s)

    fwrite(s, [char(sprintf('irun')) char([13 10])]);

end