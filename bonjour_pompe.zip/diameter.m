function diameter(s,nb)

    fwrite(s, [char(sprintf('diameter ' + string(nb))) char([13 10])]);

end